<?php
    $dbuser="root";
    $dbpass="";
    $host="localhost";
    $db="hostelmsphp";
    $mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>